## List of original footages
* Lions fighting Zebras: https://www.youtube.com/watch?v=7Wexb_7ALmU
* Man driving expensive car: https://www.youtube.com/watch?v=pHk2LGraF90
* Drone recording of car festival: https://www.youtube.com/watch?v=ojgtWheibFM
* Drone recording of car festival #2: https://www.youtube.com/watch?v=GxCQDBPimms
* Drone recording of canal festival: https://www.youtube.com/watch?v=k31eo5XsIdM
* Man caught in CCTV: https://www.youtube.com/watch?v=yGdkAiWY8Wk
* Drone recording of Farm: https://www.youtube.com/watch?v=5F_MJH2jbrg
